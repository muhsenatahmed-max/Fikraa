-- ============================================================
--  Fikra Database Schema for Supabase
--  Run this in Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ===================== PROFILES =====================
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text,
  birth_date date,
  gender text check (gender in ('male', 'female', 'other')),
  bio text,
  phone text,
  preferred_language text default 'am',
  is_verified boolean default false,
  is_premium boolean default false,
  premium_expires_at timestamptz,
  last_active timestamptz default now(),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ===================== PHOTOS =====================
create table public.user_photos (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  url text not null,
  position int default 0,
  created_at timestamptz default now()
);

-- ===================== INTERESTS =====================
create table public.user_interests (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  interest text not null
);

-- ===================== PREFERENCES =====================
create table public.user_preferences (
  user_id uuid references public.profiles(id) on delete cascade primary key,
  min_age int default 18,
  max_age int default 70,
  max_distance int default 50, -- km
  interested_in text[] default array['male','female','other']
);

-- ===================== LIKES =====================
create table public.likes (
  id uuid default uuid_generate_v4() primary key,
  from_user_id uuid references public.profiles(id) on delete cascade not null,
  to_user_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamptz default now(),
  unique(from_user_id, to_user_id)
);

-- ===================== MATCHES =====================
create table public.matches (
  id uuid default uuid_generate_v4() primary key,
  user1_id uuid references public.profiles(id) on delete cascade not null,
  user2_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamptz default now(),
  unique(user1_id, user2_id)
);

-- ===================== MESSAGES =====================
create table public.messages (
  id uuid default uuid_generate_v4() primary key,
  match_id uuid references public.matches(id) on delete cascade not null,
  sender_id uuid references public.profiles(id) on delete cascade not null,
  content text,
  message_type text default 'text' check (message_type in ('text','image','voice')),
  media_url text,
  is_read boolean default false,
  created_at timestamptz default now()
);

-- ===================== REPORTS =====================
create table public.reports (
  id uuid default uuid_generate_v4() primary key,
  reporter_id uuid references public.profiles(id) on delete cascade not null,
  reported_user_id uuid references public.profiles(id) on delete cascade not null,
  reason text,
  description text,
  status text default 'pending',
  created_at timestamptz default now()
);

-- ===================== BLOCKS =====================
create table public.blocks (
  id uuid default uuid_generate_v4() primary key,
  blocker_id uuid references public.profiles(id) on delete cascade not null,
  blocked_user_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamptz default now(),
  unique(blocker_id, blocked_user_id)
);

-- ===================== PAYMENTS =====================
create table public.payments (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  amount numeric not null,
  currency text default 'ETB',
  payment_type text check (payment_type in ('registration','premium')),
  payment_provider text, -- chapa, telebirr, stripe
  transaction_id text,
  status text default 'pending',
  created_at timestamptz default now()
);

-- ===================== INDEXES =====================
create index idx_likes_from on public.likes(from_user_id);
create index idx_likes_to on public.likes(to_user_id);
create index idx_matches_user1 on public.matches(user1_id);
create index idx_matches_user2 on public.matches(user2_id);
create index idx_messages_match on public.messages(match_id);
create index idx_profiles_last_active on public.profiles(last_active);

-- ===================== RLS (Row Level Security) =====================
alter table public.profiles enable row level security;
alter table public.user_photos enable row level security;
alter table public.user_interests enable row level security;
alter table public.user_preferences enable row level security;
alter table public.likes enable row level security;
alter table public.matches enable row level security;
alter table public.messages enable row level security;
alter table public.reports enable row level security;
alter table public.blocks enable row level security;
alter table public.payments enable row level security;

-- Basic policies (customize later)
create policy "Users can view all profiles" on public.profiles for select using (true);
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id);
create policy "Users can insert own profile" on public.profiles for insert with check (auth.uid() = id);

create policy "Users can manage own photos" on public.user_photos for all using (auth.uid() = user_id);
create policy "Users can manage own interests" on public.user_interests for all using (auth.uid() = user_id);
create policy "Users can manage own preferences" on public.user_preferences for all using (auth.uid() = user_id);

create policy "Users can create likes" on public.likes for insert with check (auth.uid() = from_user_id);
create policy "Users can see own likes" on public.likes for select using (auth.uid() = from_user_id or auth.uid() = to_user_id);

create policy "Users can see own matches" on public.matches for select using (auth.uid() = user1_id or auth.uid() = user2_id);

create policy "Users can see messages of their matches" on public.messages for select using (
  exists (select 1 from public.matches m where m.id = match_id and (m.user1_id = auth.uid() or m.user2_id = auth.uid()))
);
create policy "Users can send messages" on public.messages for insert with check (auth.uid() = sender_id);

create policy "Users can create reports" on public.reports for insert with check (auth.uid() = reporter_id);
create policy "Users can manage own blocks" on public.blocks for all using (auth.uid() = blocker_id);
create policy "Users can see own payments" on public.payments for select using (auth.uid() = user_id);
create policy "Users can insert own payments" on public.payments for insert with check (auth.uid() = user_id);

-- ===================== FUNCTION: Create match on mutual like =====================
create or replace function public.check_mutual_like()
returns trigger as $$
begin
  if exists (
    select 1 from public.likes
    where from_user_id = new.to_user_id and to_user_id = new.from_user_id
  ) then
    insert into public.matches (user1_id, user2_id)
    values (
      least(new.from_user_id, new.to_user_id),
      greatest(new.from_user_id, new.to_user_id)
    )
    on conflict do nothing;
  end if;
  return new;
end;
$$ language plpgsql security definer;

create trigger on_like_create_match
  after insert on public.likes
  for each row execute procedure public.check_mutual_like();

-- ===================== FUNCTION: Handle new user =====================
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data->>'full_name');
  insert into public.user_preferences (user_id) values (new.id);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
