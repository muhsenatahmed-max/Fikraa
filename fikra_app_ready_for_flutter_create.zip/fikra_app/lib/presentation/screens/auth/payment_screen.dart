import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/services/payment/payment_service.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  String _selectedMethod = 'chapa';
  bool _isProcessing = false;
  final _paymentService = PaymentService();

  PaymentProvider get _provider {
    switch (_selectedMethod) {
      case 'telebirr':
        return PaymentProvider.telebirr;
      case 'stripe':
        return PaymentProvider.stripe;
      default:
        return PaymentProvider.chapa;
    }
  }

  Future<void> _processPayment() async {
    setState(() => _isProcessing = true);

    try {
      final result = await _paymentService.initiateRegistrationPayment(
        provider: _provider,
        userEmail: 'user@example.com', // TODO: get from auth state
        userPhone: '+2519xxxxxxxx',     // TODO: get from auth state
        firstName: 'Fikra',
        lastName: 'User',
        currency: _provider == PaymentProvider.stripe ? 'USD' : 'ETB',
        amount: _provider == PaymentProvider.stripe
            ? AppConstants.registrationFeeUSD
            : AppConstants.registrationFeeETB,
      );

      if (!mounted) return;

      if (result.status == PaymentStatus.pending && result.checkoutUrl != null) {
        // Open Chapa checkout in browser / WebView
        final uri = Uri.parse(result.checkoutUrl!);
        if (await canLaunchUrl(uri)) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
          // After user returns, you should verify the payment
          _showVerificationDialog(result.transactionId!);
        } else {
          _showError('Checkout URL ማስከፈት አልተቻለም');
        }
      } else if (result.status == PaymentStatus.pending && result.message != null) {
        // Stripe clientSecret path – integrate flutter_stripe here
        // For now we simulate success for demo
        _showSuccessAndContinue();
      } else if (result.status == PaymentStatus.success) {
        _showSuccessAndContinue();
      } else {
        _showError(result.message ?? 'ክፍያ አልተሳካም');
      }
    } catch (e) {
      _showError(e.toString());
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  void _showVerificationDialog(String txRef) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('ክፍያ ማረጋገጫ'),
        content: const Text(
          'ክፍያውን ከጨረሱ በኋላ ከታች ያለውን ቁልፍ ይጫኑ።',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('ሰርዝ'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(ctx);
              setState(() => _isProcessing = true);
              final verify = await _paymentService.verifyChapaPayment(txRef);
              setState(() => _isProcessing = false);
              if (verify.status == PaymentStatus.success) {
                _showSuccessAndContinue();
              } else {
                _showError(verify.message ?? 'ክፍያ አልተረጋገጠም');
              }
            },
            child: const Text('አረጋግጥ'),
          ),
        ],
      ),
    );
  }

  void _showSuccessAndContinue() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('ክፍያ በተሳካ ሁኔታ ተጠናቋል! 🎉'),
        backgroundColor: AppColors.success,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/profile-setup');
      }
    });
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppColors.error,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('ክፍያ'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Price card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF9B2335), Color(0xFF7A1C2A)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withOpacity(0.35),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text(
                        'አንድ ጊዜ ብቻ',
                        style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'መመዝገቢያ ክፍያ',
                      style: TextStyle(color: Colors.white70, fontSize: 15),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${AppConstants.registrationFeeETB.toStringAsFixed(0)} ብር',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                        letterSpacing: -1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '≈ \$${AppConstants.registrationFeeUSD}  •  €${AppConstants.registrationFeeEUR}',
                      style: TextStyle(color: Colors.white.withOpacity(0.75), fontSize: 14),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _BenefitChip(icon: Icons.all_inclusive, text: 'ለሕይወት'),
                        const SizedBox(width: 10),
                        _BenefitChip(icon: Icons.verified_user, text: 'ደህንነት'),
                        const SizedBox(width: 10),
                        _BenefitChip(icon: Icons.favorite, text: 'Matching'),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),

              const Text(
                'የክፍያ ዘዴ ይምረጡ',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 14),

              _PaymentMethodTile(
                title: 'Chapa',
                subtitle: 'ካርድ • ቴሌብር • CBE Birr',
                icon: Icons.credit_card_rounded,
                isSelected: _selectedMethod == 'chapa',
                onTap: () => setState(() => _selectedMethod = 'chapa'),
              ),
              const SizedBox(height: 10),
              _PaymentMethodTile(
                title: 'Telebirr',
                subtitle: 'የኢትዮ ቴሌኮም ቴሌብር',
                icon: Icons.phone_android_rounded,
                isSelected: _selectedMethod == 'telebirr',
                onTap: () => setState(() => _selectedMethod = 'telebirr'),
              ),
              const SizedBox(height: 10),
              _PaymentMethodTile(
                title: 'Card / Apple Pay / Google Pay',
                subtitle: 'Visa • Mastercard • Stripe',
                icon: Icons.payment_rounded,
                isSelected: _selectedMethod == 'stripe',
                onTap: () => setState(() => _selectedMethod = 'stripe'),
              ),

              const Spacer(),

              ElevatedButton(
                onPressed: _isProcessing ? null : _processPayment,
                child: _isProcessing
                    ? const SizedBox(
                        height: 22,
                        width: 22,
                        child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                      )
                    : const Text('አሁን ይክፈሉ'),
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.lock_outline_rounded, size: 14, color: Colors.grey.shade500),
                  const SizedBox(width: 6),
                  Text(
                    'ክፍያዎ በደህንነት የተጠበቀ ነው',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BenefitChip extends StatelessWidget {
  final IconData icon;
  final String text;
  const _BenefitChip({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: Colors.white),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(color: Colors.white, fontSize: 11)),
        ],
      ),
    );
  }
}

class _PaymentMethodTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _PaymentMethodTile({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? AppColors.primary : Colors.grey.shade200,
            width: isSelected ? 2 : 1,
          ),
          boxShadow: isSelected
              ? [BoxShadow(color: AppColors.primary.withOpacity(0.12), blurRadius: 12, offset: const Offset(0, 4))]
              : null,
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: isSelected ? AppColors.primary.withOpacity(0.12) : Colors.grey.shade50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: isSelected ? AppColors.primary : Colors.grey.shade600),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                      color: isSelected ? AppColors.primary : AppColors.textDark,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(subtitle, style: TextStyle(fontSize: 12, color: Colors.grey.shade500)),
                ],
              ),
            ),
            Icon(
              isSelected ? Icons.check_circle_rounded : Icons.circle_outlined,
              color: isSelected ? AppColors.primary : Colors.grey.shade300,
            ),
          ],
        ),
      ),
    );
  }
}
