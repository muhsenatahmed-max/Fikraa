import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/theme/app_theme.dart';
import 'presentation/screens/onboarding/splash_screen.dart';
import 'presentation/screens/onboarding/language_screen.dart';
import 'presentation/screens/onboarding/onboarding_screen.dart';
import 'presentation/screens/auth/login_screen.dart';
import 'presentation/screens/auth/register_screen.dart';
import 'presentation/screens/auth/payment_screen.dart';
import 'presentation/screens/profile/profile_setup_screen.dart';
import 'presentation/screens/discover/discover_screen.dart';
import 'presentation/screens/matches/matches_screen.dart';
import 'presentation/screens/chat/chat_list_screen.dart';
import 'presentation/screens/settings/settings_screen.dart';
import 'presentation/screens/main_shell.dart';

class FikraApp extends ConsumerWidget {
  const FikraApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp(
      title: 'Fikra',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/language': (context) => const LanguageScreen(),
        '/onboarding': (context) => const OnboardingScreen(),
        '/login': (context) => const LoginScreen(),
        '/register': (context) => const RegisterScreen(),
        '/payment': (context) => const PaymentScreen(),
        '/profile-setup': (context) => const ProfileSetupScreen(),
        '/main': (context) => const MainShell(),
        '/discover': (context) => const DiscoverScreen(),
        '/matches': (context) => const MatchesScreen(),
        '/chats': (context) => const ChatListScreen(),
        '/settings': (context) => const SettingsScreen(),
      },
    );
  }
}
