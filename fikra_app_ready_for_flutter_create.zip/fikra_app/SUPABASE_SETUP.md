# Fikra – Supabase Backend Setup Guide

## 1. Create Supabase Project

1. Go to https://supabase.com and sign up / log in
2. Click **New Project**
3. Choose organization, name the project `fikra`, set a strong database password
4. Wait until the project is ready (~2 minutes)

## 2. Get API Keys

1. Go to **Project Settings → API**
2. Copy:
   - **Project URL** → paste into `AppConstants.supabaseUrl`
   - **anon public** key → paste into `AppConstants.supabaseAnonKey`

Open `lib/core/constants/app_constants.dart` and replace the placeholders.

## 3. Run the Database Schema

1. In Supabase Dashboard go to **SQL Editor**
2. Click **New query**
3. Copy the entire content of `supabase_schema.sql`
4. Paste and click **Run**

This creates all tables, indexes, RLS policies, and the mutual-like trigger.

## 4. Enable Auth Providers

1. Go to **Authentication → Providers**
2. Enable **Email**
3. (Optional) Enable **Phone** if you want OTP with phone numbers
4. For Phone you need an SMS provider (Twilio, MessageBird, etc.)

## 5. Storage (for profile photos)

1. Go to **Storage**
2. Create a new bucket named `avatars` (or `photos`)
3. Make it **Public** (or use signed URLs later)
4. Add policy so authenticated users can upload to their own folder

## 6. Test the connection

```bash
flutter pub get
flutter run
```

If the keys are correct, the app will start without Supabase errors.

## 7. What is already wired

| Feature              | Status                          |
|----------------------|---------------------------------|
| Supabase init        | ✅ in main.dart                 |
| Auth service         | ✅ email + phone OTP structure  |
| Profile repository   | ✅ CRUD + Discover + Like       |
| Mutual match trigger | ✅ automatic in database        |
| Payments table       | ✅ ready                        |
| RLS policies         | ✅ basic protection             |

## Next recommended steps

- Connect Register / Login screens to `AuthService`
- After successful payment call `ProfileRepository.recordPayment(...)`
- Replace demo profiles in Discover with `getDiscoverProfiles()`
- Add realtime listeners for new matches and messages

## Security reminder

- Never put the **service_role** key in the mobile app
- Keep only the **anon** key in the client
- All sensitive logic (payment verification, admin) should live in Edge Functions or your own backend
