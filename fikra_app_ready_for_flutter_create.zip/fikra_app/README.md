# Fikra ❤️

**ፍቅር ይጀምራል** — Where hearts connect.

A modern dating & matching app with paid registration, verification, multi-language support, and global reach.

## Features (MVP)

- Splash + Language selection + Onboarding
- Registration (Phone / Email) + OTP ready
- One-time Registration Payment (Chapa / Telebirr / Stripe ready)
- Multi-step Profile Setup
- Discover / Swipe (Like & Pass)
- Matches & Chat (structure ready)
- Premium upgrade UI
- Bottom navigation shell
- Beautiful Deep Rose + Soft Gold design system

## Tech Stack

- **Flutter** (Android + iOS + Web)
- **State management**: Riverpod
- **Backend (recommended)**: Supabase
- **Payments**: Chapa + Stripe
- **Routing**: Named routes (can upgrade to go_router)

## Getting Started

1. Install Flutter SDK (https://flutter.dev)
2. Clone / download this project
3. Run:
   ```bash
   flutter pub get
   flutter run
   ```

4. Replace Supabase keys in `lib/core/constants/app_constants.dart`

## Project Structure

```
lib/
├── core/           # Theme, constants, services
├── data/           # Models, repositories
├── domain/         # Entities
├── presentation/   # Screens & widgets
│   ├── screens/
│   │   ├── auth/
│   │   ├── onboarding/
│   │   ├── profile/
│   │   ├── discover/
│   │   ├── matches/
│   │   ├── chat/
│   │   └── settings/
│   └── widgets/
└── l10n/           # Localization (50 languages planned)
```

## Design System

- Primary: `#9B2335` (Deep Rose)
- Secondary: `#FDF6F0` (Warm Cream)
- Accent: `#D4A373` (Soft Gold)

## Next Steps

- [ ] Connect real Supabase backend
- [ ] Implement OTP verification
- [ ] Integrate Chapa & Stripe payments
- [ ] Add real image picker & upload
- [ ] Build Matching algorithm
- [ ] Real-time Chat
- [ ] Push notifications
- [ ] Full 50-language support
- [ ] Video/Voice calls

## License

Private — All rights reserved.
